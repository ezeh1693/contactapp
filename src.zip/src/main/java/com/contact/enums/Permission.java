package com.contact.enums;

/**
 * Created by emmanuel on 12/15/15.
 */
public enum Permission {
    ALL, EDIT,
}
