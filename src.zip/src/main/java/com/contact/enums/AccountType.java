package com.contact.enums;

/**
 * Created by emmanuel on 1/7/16.
 */
public enum AccountType {
    ADMIN, USER, OTHERS
}
